Dr. ZhongMei Yao
CPS 472
Assignment 1
Jon Henry

To run from terminal: python3 Henryj14_AS1.py /path/to/file/filename.txt

Sample runs:

python3 Henryj14_AS1.py test_run1_messages.txt
python3 Henryj14_AS1.py test_run2_messages.txt
